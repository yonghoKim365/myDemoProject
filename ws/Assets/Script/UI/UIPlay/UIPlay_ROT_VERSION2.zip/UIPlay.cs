﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Text;

public class UIPlay : UIBase {
	
	
	public Transform tfMiniMapStart;
	public Transform tfMiniMapEnd;

	public Transform tfMiniMapTop;
	public Transform tfMiniMapBottom;

	public Transform tfMiniMapContainer;
	
	public UILabel lbScore;
	public UILabel lbGold;
	public UILabel lbRoundInfo, lbRoundDetailInfo, lbRoundDetailInfoName;
	
	public UISprite spRoundInfoBg;
	public UILabel lbSP,lbMP;
	public UISprite pbSP,pbMP;

	public UIPlayUnitSlot[] UIUnitSlot = new UIPlayUnitSlot[5];
	public UIPlaySkillSlot[] uiSkillSlot = new UIPlaySkillSlot[3];
	
	
	public UIButton btnPause, btnSkipCutScene;

	public Animation aniReadyBattle;
	public GameObject readyBattle;

	public GameObject pvpContainer;

	public UIPlayResult popupResult;
	
	public Transform gameCameraContainer;
	
	public Transform gameCameraPosContainer;
	
	
	public Transform panelTop;
	public Transform panelBottom;
	
	public BoxCollider bcIgnoreGameTouch;
	public bool canTouch = true;
	
	/*
	bool _sss = false;
	public bool canTouch
	{
		set
		{
			Debug.LogError("canTouch : " + value);
			_sss = value;
		}
		get{
			return _sss;
		}
	}
	*/	
	
	
	void Awake()
	{
		gameObject.SetActive(false);
	}
	
	void Start()
	{
		UIEventListener.Get(btnSkipCutScene.gameObject).onClick = onSkipCutScene;
	}
	
	public Camera gameCamera; // game perspective camera
	
	public override void hide ()
	{
		_minimapTouched = false;
		_minimapTouchFingerId = -10000;
		resetCamera();		
		clearTweener();
		cameraTarget = null;
		targetChanageTweening = false;
		csCamMoveType = 0;
		base.hide ();
		
	}
	
	public override void show ()
	{
		base.show();
		_minimapTouched = false;
		_minimapTouchFingerId = -10000;
		//init();
	}
	
	
	void clearTweener()
	{
		Debug.Log("clear tweener!!");
		len = tweener.Count;
		for(i = 0; i < len; ++i)
		{
			tweener[i].delete();
		}
		tweener.Clear();
	}
	
	
	void onChangeView(GameObject go)
	{
		changeCamera();
	}
	
	
	void onSkipCutScene(GameObject go)
	{
		GameManager.me.cutSceneManager.skipCutScene();	
	}
	
	
	[HideInInspector]
	public Transform cameraTarget;
	
	
	public void init()
	{
//		GameManager.me.player.hp = GameDataManager.selectedPlayerData.hpMax;
//		GameManager.me.player.mp = GameDataManager.selectedPlayerData.mpMax;
//		GameManager.me.player.sp = GameDataManager.selectedPlayerData.spMax;		
		
		popupResult.gameObject.SetActive(false);
		pvpContainer.gameObject.SetActive(false);
		playerHpBar.gameObject.SetActive(true);
		spRoundInfoBg.gameObject.SetActive(true);
		lbRoundDetailInfoName.gameObject.SetActive(true);
		lbRoundDetailInfo.gameObject.SetActive(true);
		
		updateScore(0);
		updateGold(0);
		
		switch(GameManager.me.stageManager.nowRound.mode)
		{
		case RoundData.MODE.KILLEMALL :
			lbRoundInfo.text = "모든 적 죽이기";
			spRoundInfoBg.height = 64;						
			lbRoundDetailInfo.text ="";
			lbRoundDetailInfoName.text = "";
			break;
		case RoundData.MODE.ARRIVE :
			lbRoundInfo.text = "목표지점 도착하기";
			spRoundInfoBg.height = 90;						
			lbRoundDetailInfo.text = GameManager.me.stageManager.nowRound.targetPos + "m";			
			lbRoundDetailInfoName.text = "목표지점:";		
			break;
		case RoundData.MODE.SURVIVAL :
			lbRoundInfo.text = "서바이벌";
			spRoundInfoBg.height = 64;	
			lbRoundDetailInfo.text ="";		
			lbRoundDetailInfoName.text = "";
			break;
		case RoundData.MODE.DESTROY :
			lbRoundInfo.text = "파괴하기";
			spRoundInfoBg.height = 90;	
			lbRoundDetailInfo.text ="";
			lbRoundDetailInfoName.text = "남은목표물:";
			break;
		case RoundData.MODE.KILLCOUNT :
			lbRoundInfo.text = "몬스터사냥";
			spRoundInfoBg.height = 90;	
			lbRoundDetailInfo.text ="";
			lbRoundDetailInfoName.text = "남은개수:";
			break;
		case RoundData.MODE.KILLCOUNT2:
			lbRoundInfo.text = "몬스터사냥";
			spRoundInfoBg.height = 90;	
			lbRoundDetailInfo.text ="";
			lbRoundDetailInfoName.text = "남은개수:";
			break;
		case RoundData.MODE.PVP:
			pvpContainer.gameObject.SetActive(true);
			playerHpBar.gameObject.SetActive(false);
			spRoundInfoBg.gameObject.SetActive(false);
			lbRoundDetailInfoName.gameObject.SetActive(false);
			lbRoundDetailInfo.gameObject.SetActive(false);
			break;
		default:
			lbRoundInfo.text = GameManager.me.stageManager.nowRound.mode;	
			spRoundInfoBg.height = 64;	
			lbRoundDetailInfoName.text = "";
			lbRoundDetailInfo.text ="";
			break;
			
		}
		
		//if(GameManager.me.stageManager.nowRound.settingTime > -1) lbRoundInfo.text += "\n Time: " + GameManager.me.stageManager.nowRound.settingTime;
		updateLeftTime = (GameManager.me.stageManager.nowRound.settingTime > -1);
		
		GameDataManager.instance.score  = 0;
	
		cameraTarget = GameManager.me.player.cTransform;
		
		_v = panelTop.localPosition;
		_v.x = 0.0f;
		_v.z = 0.0f;
		_v.y = 190.0f;
		panelTop.localPosition = _v;
		
		_v = panelBottom.localPosition;
		_v.x = 0.0f;
		_v.z = 0.0f;		
		_v.y = -190.0f;
		panelBottom.localPosition = _v;		
		
		readyBattle.SetActive(false);
		
		if(GameManager.me.cutSceneManager.nowOpenCutScene == false) resetCamera();
		
		bcIgnoreGameTouch.gameObject.SetActive(false);
		
		prevPlayTime = 0.0f;
		tfPlayTime.text = "";
		
		canTouch = true;
		
		clearTweener();
	}
	
	
	
	// show, hide 메뉴는 시간이 있으면 트위닝 되어서 나타나거나 사라진다.
	// 시간이 없으면 바로 나타남.
	// ignoreGameUI를 설정하면 ui 클릭을 막을 수 있다.
	public void showMenu(float time = 0.3f, bool ignoreGameUI = false)
	{
		bcIgnoreGameTouch.gameObject.SetActive(ignoreGameUI);
		
		if(time > 0)
		{
			_v = panelTop.position;
			_v.x = 0.0f;
			_v.y = 0.0f;
			_v.z = 0.0f;
			TweenPosition.Begin(panelTop.gameObject, time, _v).method = UITweener.Method.EaseInOut;		
			_v = panelBottom.position;
			_v.x = 0.0f;
			_v.y = 0.0f;
			_v.z = 0.0f;
			TweenPosition.Begin(panelBottom.gameObject, time, _v).method = UITweener.Method.EaseInOut;		
		}
		else
		{
			_v = panelTop.position;
			_v.x = 0.0f;
			_v.y = 0.0f;
			_v.z = 0.0f;	
			panelTop.localPosition = _v;
			
			_v = panelBottom.position;
			_v.x = 0.0f;
			_v.y = 0.0f;
			_v.z = 0.0f;	
			panelBottom.localPosition = _v;	
		}
	}
	
	public void hideMenu(float time = 0.3f)
	{
		if(time > 0)
		{
			_v = panelTop.position;
			
			if(_v.x != 0.0f && _v.y != 190.0f && _v.z != 0.0f)
			{
				_v.x = 0.0f;
				_v.z = 0.0f;
				_v.y = 190.0f;
				TweenPosition.Begin(panelTop.gameObject, time, _v).method = UITweener.Method.EaseInOut;		
				_v = panelBottom.position;
				_v.x = 0.0f;
				_v.z = 0.0f;		
				_v.y = -190.0f;
				TweenPosition.Begin(panelBottom.gameObject, time, _v).method = UITweener.Method.EaseInOut;				
			}
			else
			{
				hideMenu(0.0f);
			}
		}
		else
		{
			_v = panelTop.localPosition;
			_v.x = 0.0f;
			_v.z = 0.0f;
			_v.y = 190.0f;
			panelTop.localPosition = _v;
			
			_v = panelBottom.localPosition;
			_v.x = 0.0f;
			_v.z = 0.0f;		
			_v.y = -190.0f;
			panelBottom.localPosition = _v;			
		}
	}
	
	
	
	// 배틀 애니메이션.
	public void showReadyBattleAnimation()
	{
		GameManager.soundManager.playEffect("eff/start_battle");
		readyBattle.SetActive(true);
		//aniReadyBattle.Play();
	}
	
	
	public void hideReadyBattleAnimation()
	{
		//aniReadyBattle.Stop();
		readyBattle.SetActive(false);
	}
	
	
	
	
	public void addScore(int num)
	{
		GameDataManager.instance.score += num;
		lbScore.text = Util.GetCommaScore(GameDataManager.instance.score);
	}
	
	public void updateScore(int num)
	{
		lbScore.text = Util.GetCommaScore(num);
	}

	public void updateGold(int num)
	{
		//lbGold.text = Util.GetCommaScore(num);
	}

	private StringBuilder _sb = new StringBuilder();

	public PlayerHpBar playerHpBar;
	public PlayerHpBar playerPVPMeHpBar;
	public PlayerHpBar playerPVPEnemyHpBar;

	public void updateHP(float hpPer, float hp, float maxHp)
	{
		playerPVPMeHpBar.updateHP(hpPer, hp, maxHp);
		playerHpBar.updateHP(hpPer, hp, maxHp);

//		if(GameManager.me.stageManager.nowRound.mode == RoundData.MODE.PVP)
//		{
//		}
//		else
//		{
//		}
	}

	public void updateMP(float mp, float maxMp)
	{
		_sb.Length = 0;
		_sb.Append((int)mp);
		_sb.Append("/");
		_sb.Append(maxMp);
		lbMP.text = _sb.ToString();
		pbMP.fillAmount = mp/maxMp;
	}

	public void updateSP(float sp, float maxSp)
	{
		_sb.Length = 0;
		_sb.Append((int)sp);
		_sb.Append("/");
		_sb.Append(maxSp);
		lbSP.text = _sb.ToString();
		pbSP.fillAmount = sp/maxSp;
	}	
	
	
	public void updatePetSlot()
	{
		for(i = 0; i < 5; ++i)
		{
			UIUnitSlot[i].update();
		}
	}
	
	public void resetPetSlotCoolTime()
	{
		for(i = 0; i < 5; ++i)
		{
			UIUnitSlot[i].resetCoolTime();
		}
	}
	
	
	
	public void updateSkillSlot()
	{
		for(i = 0; i < 3; ++i)
		{
			uiSkillSlot[i].update();
		}
	}
	
	public void resetSkillSlotCoolTime()
	{
		for(i = 0; i < 5; ++i)
		{
			uiSkillSlot[i].resetCoolTime();
		}
	}	
	
	

	float _tempF;
	float _tempF2;	


	public Camera uiPlayCamera;
	Touch _t;
	private int _minimapTouchFingerId = -10000;
	private bool _minimapTouched = false;

	private float _minimapPointPosition = 0;


	void LateUpdate()
	{
		if(GameManager.me.uiManager.currentUI != UIManager.STATUS.UI_PLAY || GameManager.me.isPaused) return;
		
		if(GameManager.me.cutSceneManager.useCutSceneCamera == true) //GameManager.me.cutSceneManager.nowOpenCutScene == false)// || 
		{
			playCSCam();
			
		}
		else if(GameManager.me.isPlaying)// 컷씬 진행중일때는 컷씬의 카메라 셋팅이 우선된다.
		{
			
			CharacterMinimapPointer.startX = tfMiniMapStart.position.x;			
			CharacterMinimapPointer.endX = tfMiniMapEnd.position.x;
			CharacterMinimapPointer.yPos = tfMiniMapEnd.position.y;
			CharacterMinimapPointer.width = CharacterMinimapPointer.endX - CharacterMinimapPointer.startX ;

			bool resetCamPos = _minimapTouched;


#if UNITY_EDITOR

			if(_minimapTouched == false && Input.GetMouseButtonDown(0))
			{
				_v = uiPlayCamera.ScreenToWorldPoint(Input.mousePosition);
				
				if(_v.x > CharacterMinimapPointer.startX
				   && _v.x < CharacterMinimapPointer.endX
				   && _v.y < tfMiniMapTop.position.y
				   && _v.y > tfMiniMapBottom.position.y)
				{
					_minimapTouched = true;
					_minimapPointPosition= StageManager.mapStartPosX + ((StageManager.mapEndPosX - StageManager.mapStartPosX)/CharacterMinimapPointer.width*(_v.x - CharacterMinimapPointer.startX));
					if(_minimapPointPosition < StageManager.mapStartPosX) _minimapPointPosition = StageManager.mapStartPosX;
					else if(_minimapPointPosition > StageManager.mapEndPosX ) _minimapPointPosition = StageManager.mapEndPosX ;
				}
			}
			else if(_minimapTouched && Input.GetMouseButton(0))
			{
				_v = uiPlayCamera.ScreenToWorldPoint(Input.mousePosition);
				_minimapPointPosition = StageManager.mapStartPosX + ((StageManager.mapEndPosX - StageManager.mapStartPosX)/CharacterMinimapPointer.width*(_v.x - CharacterMinimapPointer.startX));
				if(_minimapPointPosition < StageManager.mapStartPosX) _minimapPointPosition = StageManager.mapStartPosX;
				else if(_minimapPointPosition > StageManager.mapEndPosX ) _minimapPointPosition = StageManager.mapEndPosX ;
			}
			else
			{
				_minimapTouched = false;
				_minimapTouchFingerId = -10000;
			}
#else
			if(Input.touchCount > 0)
			{
				for(int i = 0; i < Input.touchCount; ++i)
				{
					_t = Input.GetTouch(i);
					
					if(_minimapTouched == false && _t.phase == TouchPhase.Began)
					{
						_v = uiPlayCamera.ScreenToWorldPoint(_t.position);
						
						if(_v.x > CharacterMinimapPointer.startX
						   && _v.x < CharacterMinimapPointer.endX
						   && _v.y < tfMiniMapTop.position.y
						   && _v.y > tfMiniMapBottom.position.y)
						{

							_minimapTouchFingerId = _t.fingerId;
							_minimapTouched = true;
							_minimapPointPosition= StageManager.mapStartPosX + ((StageManager.mapEndPosX - StageManager.mapStartPosX)/CharacterMinimapPointer.width*(_v.x - CharacterMinimapPointer.startX));
							if(_minimapPointPosition < StageManager.mapStartPosX) _minimapPointPosition = StageManager.mapStartPosX;
							else if(_minimapPointPosition > StageManager.mapEndPosX ) _minimapPointPosition = StageManager.mapEndPosX ;
						}
					}
					else if(_minimapTouched && _minimapTouchFingerId == _t.fingerId)
					{
						if(_t.phase == TouchPhase.Moved)
						{
							_v = uiPlayCamera.ScreenToWorldPoint(Input.mousePosition);

							_minimapPointPosition= StageManager.mapStartPosX + ((StageManager.mapEndPosX - StageManager.mapStartPosX)/CharacterMinimapPointer.width*(_v.x - CharacterMinimapPointer.startX));
							if(_minimapPointPosition < StageManager.mapStartPosX) _minimapPointPosition = StageManager.mapStartPosX;
							else if(_minimapPointPosition > StageManager.mapEndPosX ) _minimapPointPosition = StageManager.mapEndPosX ;

						}
						if(_t.phase == TouchPhase.Ended || _t.phase == TouchPhase.Canceled)
						{
							_minimapTouched = false;
							_minimapTouchFingerId = -10000;
						}

						break;
					}
				}
			}
			else
			{
				_minimapTouched = false;
				_minimapTouchFingerId = -10000;
			}
#endif

			if(resetCamPos && _minimapTouched == false)
			{
				_v = cameraTarget.position;
				_v.z = 0.0f;
				_v2 = gameCameraContainer.position;
				_tempF = (_v.x - _v2.x);
				_v2.x += _tempF;
				_v.x = _v2.x;			
				gameCameraContainer.position = _v;
			}

			playCam();
			
			if(GameManager.me.stageManager.playTime - prevPlayTime >= 0.1f)
			{
				tfPlayTime.text = GameManager.me.stageManager.playTime.ToString("#.#");	
				prevPlayTime = GameManager.me.stageManager.playTime;
				
				if(updateLeftTime)
				{
					tfLeftTime.text = (GameManager.me.stageManager.nowRound.settingTime - GameManager.me.stageManager.playTime).ToString("#");//("#.#");	
				}
				
			}			
		}
		else if(GameManager.me.playGameOver)
		{
			// 게임이 종료 됐을 때의 카메라 연출.


			if(gameCamera.fieldOfView > 8)
			{
				gameCamera.fieldOfView -= Time.smoothDeltaTime * 1.5f;	
			}
		}
		
		//=== 추후 제거될 코드들...==//
		
		//checkJoystick();
		//finchAndSelectObject();
	}
	
	
	
	
	[HideInInspector]
	public Vector3 csCamPos = new Vector3();
	[HideInInspector]
	public Vector2 csCamCenter = new Vector2();
	[HideInInspector]
	public float csCamFov;
	public int csCamMoveType;
	public Vector2 csCamOffset = new Vector2();
	private Vector3 csCamPositionCalcVector = new Vector3();
	const int CAM_MOVE_STOP = 0;
	const int CAM_MOVE_POSITION = 1;
	const int CAM_MOVE_ROTATION = 2;
	
	
	
	public void setCutSceneCamera(Transform target, bool setCamCenter, Vector2 centerPoint, bool setCamPos, Vector3 newCamPos, float fov, bool setCamRot, Vector3 newCamRot, int newMotionType = -1)
	{
		if(target != null) cameraTarget = target;
		if(setCamCenter)
		{
			csCamPositionCalcVector.x = Screen.width * gameCamera.rect.x + Screen.width * gameCamera.rect.width * (centerPoint.x /GameManager.screenSize.x);
			csCamPositionCalcVector.y = Screen.height * gameCamera.rect.y + Screen.height * gameCamera.rect.height * (centerPoint.y /GameManager.screenSize.y);

			csCamOffset.x = (GameManager.screenSize.x * 0.5f - centerPoint.x)/GameManager.screenSize.x;
			csCamOffset.y = (GameManager.screenSize.y * 0.5f - centerPoint.y)/GameManager.screenSize.y;
			csCamOffset.x = Screen.width * csCamOffset.x * gameCamera.rect.width;
			csCamOffset.y = Screen.height * csCamOffset.y * gameCamera.rect.height;
		}
		
		if(fov > 0)
		{
			csCamFov = fov;
			gameCamera.fieldOfView = fov;
		}
		if(setCamPos)
		{
			csCamPos = newCamPos;
			gameCameraPosContainer.localPosition = newCamPos;
		}
		
		if(setCamRot)
		{
			_q = gameCamera.transform.rotation;
			_q.eulerAngles = newCamRot;
			gameCamera.transform.rotation = _q;
		}
		
//		Debug.LogError("==== : " + CutSceneManager.cutScenePlayTime);
		Debug.LogError("target : " + target + "setCamPos : " + setCamPos + " setCamRot : " + setCamRot);
		if(target != null && setCamPos && setCamRot == false)
		{
			_v = gameCamera.WorldToScreenPoint(cameraTarget.position);		
			_v.x += csCamOffset.x;
			_v.y += csCamOffset.y;
			_v = gameCamera.ScreenToWorldPoint(_v);	
			gameCamera.transform.rotation = Util.getLookRotationQuaternion(_v - gameCamera.transform.position);
			//cc Log.log(_v, gameCamera.transform.position,gameCamera.transform.rotation.eulerAngles);
		}
		
		
		if(newMotionType > -1)
		{
			csCamMoveType = newMotionType;
		}
	}	
	
	

	
	bool targetChanageTweening = false;
	bool startCameraMove = false;
	int nextMotionType = 0;
	float motionStartTime;
	float motionTime;
	
	private Vector3 _startCameraPos;
	private Quaternion _startCameraRot;
	
	
	public void setCutSceneCameraMove(Transform target, bool setCamCenter, Vector2 centerPoint, bool setCamPos, Vector3 newCamPos, bool setCamRot, Vector3 newCamRot, float fov, float motionTime, int newMotionType = -1, int nowMotionType = -1)
	{
		_motionDelta = 0.0f;
		
		if(target != null) cameraTarget = target;
		if(setCamCenter)
		{
			csCamPositionCalcVector.x = Screen.width * gameCamera.rect.x + Screen.width * gameCamera.rect.width * (centerPoint.x /GameManager.screenSize.x);
			csCamPositionCalcVector.y = Screen.height * gameCamera.rect.y + Screen.height * gameCamera.rect.height * (centerPoint.y /GameManager.screenSize.y);
		
			csCamOffset.x = (GameManager.screenSize.x * 0.5f - centerPoint.x)/GameManager.screenSize.x;
			csCamOffset.y = (GameManager.screenSize.y * 0.5f - centerPoint.y)/GameManager.screenSize.y;
			csCamOffset.x = Screen.width * csCamOffset.x * gameCamera.rect.width;
			csCamOffset.y = Screen.height * csCamOffset.y * gameCamera.rect.height;
		}
		
		this.motionTime = motionTime;
		
		if((target != null || setCamCenter)) //&& setCamPos == false)
		{
			motionStartTime = Time.time;
			targetChanageTweening = true;
			_startCameraPos = gameCamera.transform.localPosition;
			_startCameraRot = gameCamera.transform.rotation;
		}
		else targetChanageTweening = false;
		
		if(fov > 0) tweener.Add(MiniTweenerFOV.start(gameCamera, fov, motionTime));
		if(setCamPos) tweener.Add(MiniTweenerLocalPosition.start(gameCameraPosContainer, newCamPos, motionTime));
		if(setCamRot) tweener.Add(MiniTweenerCamRotation.start(gameCamera, newCamRot, motionTime));
		
		nextMotionType = csCamMoveType;
		if(newMotionType > -1) nextMotionType = newMotionType;
		if(nowMotionType > -1) csCamMoveType = nowMotionType;
		
		System.Action<int> callbackFunc = onCompleteCameraMove;
		tweener.Add(MiniTweenerDelayMethod.start(motionTime, 0.0f, callbackFunc, nextMotionType));
		
	}
	
	void onCompleteCameraMove(int newMotionType)
	{
		csCamMoveType = newMotionType;
		targetChanageTweening = false;
	}
	
	
	List<MiniTweener> tweener = new List<MiniTweener>();
	
	private Vector3 _v3;
	private Vector3 _camTargetPos;	
	private int tweenCount = 0;
	private float _motionDelta = 0.0f;
	private Vector3 _targetCameraPos;
	
	
	public void playCSCam()
	{
		if(cameraTarget != null)
		{
			tweenCount = tweener.Count;
			
			for(i = tweener.Count -1; i >= 0; --i)
			{
				tweener[i].update(CutSceneManager.cutSceneDeltaTime);
				
				if(tweener[i].isComplete == true)
				{
					if(tweenCount == 0) targetChanageTweening =  false;
					tweener[i].delete();
					tweener.RemoveAt(i);
				}
			}
			
			switch(csCamMoveType)
			{
			case CAM_MOVE_POSITION:
				
				_camTargetPos = cameraTarget.position;
				
				_v = gameCamera.WorldToScreenPoint(_camTargetPos);
				csCamPositionCalcVector.z = _v.z;
				
				_v2 = gameCamera.ScreenToWorldPoint(csCamPositionCalcVector);
				
				_v3 = gameCamera.transform.localPosition;
				_v3.x -= (_v2.x - _camTargetPos.x);
				_v3.y -= (_v2.y - _camTargetPos.y);			
				
				if(targetChanageTweening)
				{
					_motionDelta += CutSceneManager.cutSceneDeltaTime;///motionTime;
					_v = gameCamera.transform.localPosition = Vector3.Lerp(_startCameraPos, _v3, _motionDelta/motionTime);//(Time.time-motionStartTime));//_v3;		motionDelta);//			
				}
				else
				{
					_v = Vector3.Lerp(gameCamera.transform.localPosition, _v3, Time.deltaTime * 7.0f);//_v3;					
				}
				
				gameCameraPosContainer.transform.localPosition += _v;
				_v.x = 0.0f;_v.y = 0.0f;_v.z = 0.0f;
				gameCamera.transform.localPosition = _v;				
				
				break;
				
			case CAM_MOVE_ROTATION:
				
				_v = gameCamera.WorldToScreenPoint(cameraTarget.position);		
				_v.x += csCamOffset.x;
				_v.y += csCamOffset.y;
				_v = gameCamera.ScreenToWorldPoint(_v);			

				if(targetChanageTweening)
				{
					_motionDelta += CutSceneManager.cutSceneDeltaTime;///motionTime;
					gameCamera.transform.rotation = Quaternion.Slerp(_startCameraRot, Util.getLookRotationQuaternion(_v - gameCamera.transform.position), _motionDelta/motionTime);//(Time.time-motionStartTime));
				}
				else
				{
					//gameCamera.transform.rotation = Quaternion.LookRotation((_v) - gameCamera.transform.position);
					gameCamera.transform.rotation = Quaternion.Slerp(gameCamera.transform.rotation, Util.getLookRotationQuaternion(_v - gameCamera.transform.position), Time.deltaTime * 7.0f);//(Time.time-motionStartTime));
				}	
				
				break;
				
			default:
				_v = gameCamera.transform.localPosition;
				gameCameraPosContainer.transform.localPosition += _v;
				_v.x = 0.0f;_v.y = 0.0f;_v.z = 0.0f;
				gameCamera.transform.localPosition = _v;
				break;
			}
		}
	}	
	
	
	public void playCam()
	{
		if(_minimapTouched)
		{
			_v = cameraTarget.position;
			_v.x = _minimapPointPosition;
			_v.z = 0.0f;
			_v2 = gameCameraContainer.position;
			_tempF = (_v.x - _v2.x);
			_v2.x += _tempF;
			_v.x = _v2.x;			
			gameCameraContainer.position = _v;
			return;
		}

		if(cameraTarget == null) return;

		// === 특정 좌표로 캐릭터를 고정 시킨후 회전.
		/*
		_v = gameCamera.WorldToScreenPoint(cameraTarget.position);		
		_v.x += camRotOffset.x;
		_v.y += camRotOffset.y;
		_v = gameCamera.ScreenToWorldPoint(_v);			
		
		gameCamera.transform.rotation = Quaternion.Slerp(gameCamera.transform.rotation, Util.getLookRotationQuaternion(_v - gameCamera.transform.position), 1.0f);//(Time.time-motionStartTime));

		_v = cameraTarget.position;
		_v.z = 0.0f;
		*/

		// ==== 카메라가 지연되어 캐릭터를 쫓아가는 효과. ==== //
		_v2 = gameCameraContainer.position;

		_tempF = (_v.x - _v2.x);

//		_v2.x += _tempF;// * (Time.smoothDeltaTime) * GameManager.info.setupData.defaultPlayCamSpringValue[0];
//		_v.x = _v2.x;	

		if(GameManager.me.player.moveState != Player.MoveState.Stop)
		{
			_v2.x += _tempF * (Time.smoothDeltaTime) * GameManager.info.setupData.defaultPlayCamSpringValue[0];
			_v.x = _v2.x;			
		}
		else
		{
			_v2.x += _tempF * (Time.smoothDeltaTime) * GameManager.info.setupData.defaultPlayCamSpringValue[1];
			_v.x = _v2.x;
		}

		//gameCameraContainer.position = Vector3.Lerp(gameCameraContainer.position,_v,Time.smoothDeltaTime * rotSpeed);
		gameCameraContainer.position = _v;//Vector3.Lerp(gameCameraContainer.position,_v,Time.smoothDeltaTime);

	

		// ==== 캐릭터 이동시 화면 움직이는 효과 ==== //
		
		_v = cameraTarget.position;
		_v2 = gameCameraContainer.position;		
		
		_tempF = (_v.x - _v2.x);
		
		_q = gameCameraContainer.rotation;
		_q2 = gameCameraContainer.rotation;
		_v2 =  _q.eulerAngles;		
		_v2.x = rx;
		
		_tempF *= GameManager.globalDeltaTime * 2.0f;
		
		_v2.y = ry + _tempF;
	
		// 최대 회전각도를 제한한다.
		//if(_v2.y < 180.0f && _v2.y > 4.0f) _v2.y = 4.0f;
		//else if(_v2.y > 180.0f && _v2.y < 356.0f) _v2.y = 356.0f;

		_q.eulerAngles = _v2;		
		
		if(GameManager.me.player.moveState != Player.MoveState.Stop)
		{
			gameCameraContainer.rotation = Quaternion.Slerp(_q2, _q, GameManager.info.setupData.defaultPlayCamSpringValue[2]);			
		}
		else
		{
			gameCameraContainer.rotation = Quaternion.Slerp(_q2, _defaultRotation, GameManager.info.setupData.defaultPlayCamSpringValue[3]);				
		}

		
		
		//==== ZOOM IN - OUT ====//
		
		//float dist = VectorUtil.Distance(GameManager.me.player.cTransformPosition.x, GameManager.me.stageManager.heroMonster[0].cTransformPosition.x);
		//dist *= 0.01f;
		//if(dist > 8.0f) dist = 8.0f;
		//GameManager.me.persCamera.fieldOfView = fov + dist - 5.0f;
		
		if(GameManager.me.stageManager.heroMonster != null)
		{
			float dist = VectorUtil.Distance(GameManager.me.player.cTransformPosition.x, GameManager.me.stageManager.heroMonster[0].cTransformPosition.x);
			dist *= 0.005f;
			if(dist > 4.0f) dist = 4.0f;
		
			_newFov = fov + dist - 2.0f;
		
			if(gameCamera.fieldOfView - _newFov > Time.smoothDeltaTime * 2.0f)
			{
				gameCamera.fieldOfView -= Time.smoothDeltaTime * 2.0f;
			}
			else if(gameCamera.fieldOfView - _newFov < -Time.smoothDeltaTime * 2.0f)
			{
				gameCamera.fieldOfView += Time.smoothDeltaTime * 2.0f;
			}
			else
			{
				gameCamera.fieldOfView = _newFov;		
			}
		}		
	}


	public float rotSpeed = 0.5f;


	private float _newFov;
	private float prevPlayTime = 0.0f;
	
	private Vector3 _pv;
	private Vector3 _r;
	private float fov;

	
	public void onOpenPause()
	{

//		Time.timeScale = 1.0f;
//
//		GameManager.me.startGameOver();

		//return;

		GameManager.me.uiManager.popupPaused.Open();
		
//		if(GameManager.me.mapManager.loadedMap.mapFile != null)
//		{
//			GameManager.me.mapManager.loadedMap.mapFile.SetActive(!GameManager.me.mapManager.loadedMap.mapFile.activeSelf);
//		}
		
		/*
		if(GameManager.me.mapManager.loadedMap.mapFile.activeSelf)
		{
			++PerformanceManager.GetInstance().lowPc;
		}
		*/
//		MapTesterHelper.instance.nextMap();
	}
	
	
	private float _draggingDistance = 0.0f;
	private bool _isTouchDragging = false;

	
	private float _dragginDistance2 = 0.0f;
	private bool _isTouchDragging2 = false;
	private bool _checkTouchStart = false;	
	
	private float touchDistance;	
	private Vector2 prevMousePosition = Vector2.zero;	
	
	public Transform characterStage;
	private Vector3 _v;
	
	private GameObject currentSelectObject;
	
	private bool _isMouseDown = false;
	private bool _isMouseDownStart = false;
	
	
	// Update is called once per frame
	private bool finchAndSelectObject () {
		
		Vector2 mousePos = Vector2.zero;
		
		bool isMouseUp = false;
		bool isDrag = false;
		
#if UNITY_EDITOR
		
			if(_isMouseDown == false) _isMouseDown = Input.GetMouseButtonDown(0);
			isMouseUp = Input.GetMouseButtonUp(0);
			if(isMouseUp) _isMouseDown = false;
		
			mousePos = Input.mousePosition;
#elif UNITY_ANDROID || UNITY_IPHONE
			if(Input.touchCount >= 1)
			{
				Touch t = Input.GetTouch(0);
				_isMouseDown = (t.phase == TouchPhase.Began);
				isMouseUp = (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled);
				mousePos = t.position;
				isDrag = (t.phase == TouchPhase.Moved);
			}
#endif		
		
		float fx = 1.0f;
		
#if UNITY_EDITOR
		
		

		
		// 확대 축소. 핀치 줌.
		if(Input.GetAxis("Mouse ScrollWheel") > 0)
		{
			fx = Mathf.Min(GameManager.me.tk2dGameCamera.scale*1.1f, 3.0f);
			GameManager.me.tk2dGameCamera.scale = fx;
			gameCamera.fieldOfView /= 1.1f;
			setCameraCenter();
		}
		else if(Input.GetAxis("Mouse ScrollWheel") < 0)
		{
			fx = Mathf.Max(GameManager.me.tk2dGameCamera.scale/1.1f, 0.2f);
			GameManager.me.tk2dGameCamera.scale = fx;
			gameCamera.fieldOfView *= 1.1f;
			setCameraCenter();
		}
		
		// 터치가 시작한 순간.
		if(Input.GetMouseButtonDown(0))// && uiOverCheck() == false)
		{
			//Debug.Log("터치가 시작.");
			
			prevMousePosition = mousePos;
			_draggingDistance = 0.0f;
			_isTouchDragging = false;
			_isMouseDown = true;
			_isMouseDownStart = true;
		}
		
		
#elif UNITY_IPHONE || UNITY_ANDROID
		if(Input.GetKey(KeyCode.Escape))Application.Quit();
		
		if(Input.touchCount > 0)mousePos = Input.GetTouch(0).position;
		
		if(Input.touchCount == 1)
		{
			Touch touch = Input.GetTouch(0);
			
			if(touch.phase == TouchPhase.Began)
			{
				prevMousePosition = (Vector3)touch.position;
			}
			else if(touch.phase == TouchPhase.Moved)
			{
				float deltaX = prevMousePosition.x - mousePos.x;
				float deltaY = prevMousePosition.y - mousePos.y;
				_draggingDistance += ((deltaX>0)?deltaX:-deltaX)+((deltaY>0)?deltaY:-deltaY);
				if(_draggingDistance > 20.0f)
				{
					_isTouchDragging = true;
				}					

				prevMousePosition = (Vector3)touch.position;
			}
			else if(touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled)
			{
				if(currentSelectObject != null)
				{
					// 화면 이동이 이루어진 상태가 아니라면....
					// 해당 타일에 맞는 작업을 시작한다.
					if(_isTouchDragging == false)
					{
						Debug.LogError("클릭 오브젝트 : " + currentSelectObject.name);
						currentSelectObject.animation.Play("attack");						
						
					}
					
					currentSelectObject = null;
					_draggingDistance = 0.0f;
					_isTouchDragging = false;	
					
					return true;
				}
				
				_draggingDistance = 0.0f;
				_isTouchDragging = false;				
			}
		}
		else if(Input.touchCount > 1)
		{
			if(Input.GetTouch(0).phase == TouchPhase.Began || Input.GetTouch(1).phase == TouchPhase.Began)
			{
				touchDistance = Vector2.Distance(Input.GetTouch(0).position, Input.GetTouch(1).position);
			}
			else if((Input.GetTouch(0).phase == TouchPhase.Moved || Input.GetTouch(1).phase == TouchPhase.Moved)) //!uiManager.isUIOver 
			{
				float dis = Vector2.Distance(Input.GetTouch(0).position, Input.GetTouch(1).position);
			
				if(touchDistance<dis)
				{
					fx = Mathf.Min(GameManager.me.tk2dGameCamera.scale*1.02f, 3.0f);
					gameCamera.fov /= 1.02f;
					GameManager.me.tk2dGameCamera.scale = fx;
					setCameraCenter();
				}
				else if(touchDistance>dis)
				{
					fx = Mathf.Max(GameManager.me.tk2dGameCamera.scale/1.02f, 0.2f);
					gameCamera.fov *= 1.02f;
					GameManager.me.tk2dGameCamera.scale = fx;
					setCameraCenter();
				}
				touchDistance = dis;
			}
			
			if(Input.GetTouch(1).phase == TouchPhase.Ended)
			{
				prevMousePosition = (Vector3)Input.GetTouch(0).position;
				setCameraCenter();
			}else if(Input.GetTouch(0).phase == TouchPhase.Ended)
			{
				prevMousePosition = (Vector3)Input.GetTouch(1).position;
			}
			
			currentSelectObject = null;
		}
#endif
		
		return false;
	}		


	[HideInInspector]
	public Transform joystick;
	Vector2 _startP;
	Vector2 _prevP;
	Vector2 _nowP;
	
	[HideInInspector]
	public bool isDown = false;
	
	bool isCamDown = false;
	bool isCamUp = false;
	

	Quaternion _q;
	Quaternion _q2;
	Vector3 _v2;
	
	
	public UILabel tfPlayTime;
	public UILabel tfLeftTime;
	public bool updateLeftTime = false;

	private float _pointX;
	private float _pointY;
	
	private void setCameraCenter(bool settingCamRightNow = false)
	{
		if(cameraTarget == null) return;
		
		if(settingCamRightNow)
		{
			_v = cameraTarget.position;
			gameCameraContainer.position = _v;
		}		
		
		_v2.x = Screen.width * gameCamera.rect.x + Screen.width * gameCamera.rect.width * 0.22f;//(centerPoint.x /GameManager.screenSize.x);
		_v2.y = Screen.height * gameCamera.rect.y + Screen.height * gameCamera.rect.height * 0.4f;//(centerPoint.y /GameManager.screenSize.y);

		_camTargetPos = cameraTarget.position;
		
		_v = gameCamera.WorldToScreenPoint(_camTargetPos);
		_v2.z = _v.z;
		
		_v2 = gameCamera.ScreenToWorldPoint(_v2);
		
		_v3 = gameCameraPosContainer.localPosition;
		_v3.x -= (_v2.x - _camTargetPos.x);
		_v3.y -= (_v2.y - _camTargetPos.y);
		gameCameraPosContainer.localPosition = _v3;	


		camRotOffset.x = (GameManager.screenSize.x * 0.5f - (GameManager.screenSize.x * 0.22f))/GameManager.screenSize.x;
		camRotOffset.y = (GameManager.screenSize.y * 0.5f - (GameManager.screenSize.y * 0.4f))/GameManager.screenSize.y;
		camRotOffset.x = Screen.width * camRotOffset.x * gameCamera.rect.width;
		camRotOffset.y = Screen.height * camRotOffset.y * gameCamera.rect.height;
		
		//camRotOffset.x = Screen.width * gameCamera.rect.x + Screen.width * gameCamera.rect.width * 0.22f;//(centerPoint.x /GameManager.screenSize.x);
		//camRotOffset.y = Screen.height * gameCamera.rect.y + Screen.height * gameCamera.rect.height * 0.4f;//(centerPoint.y /GameManager.screenSize.y);
	}	
	
	Vector2 camRotOffset = Vector2.zero;

	public void resetCamera()
	{
		Debug.Log("resetCamera!!!");
		cameraTarget = GameManager.me.player.cTransform;

		camRotOffset.x = (GameManager.screenSize.x * 0.5f - (GameManager.screenSize.x * 0.22f))/GameManager.screenSize.x;
		camRotOffset.y = (GameManager.screenSize.y * 0.5f - (GameManager.screenSize.y * 0.4f))/GameManager.screenSize.y;
		camRotOffset.x = Screen.width * camRotOffset.x * gameCamera.rect.width;
		camRotOffset.y = Screen.height * camRotOffset.y * gameCamera.rect.height;
		
		
		_v = gameCameraContainer.position;
		_v.x = 0.0f; _v.y = 0.0f; _v.z = 0.0f;
		gameCameraContainer.position = _v;		
		
		_q = gameCameraContainer.transform.rotation;
		_v = _q.eulerAngles;_v.x = 0.0f;_v.y = 0.0f;_v.z = 0.0f;_q.eulerAngles = _v;
		gameCameraContainer.transform.rotation = _q;	
		
		_v = GameManager.me.gameCamera.transform.parent.transform.localPosition;
		_v.x = 0.0f;_v.y = 0.0f;_v.z = 0.0f;
		GameManager.me.gameCamera.transform.parent.transform.localPosition = _v;		
		
		/*
		_v = gameCameraPosContainer.localPosition;
		_v.x = 370.0f;_v.y = 1121.0f;_v.z = -2168.0f;
		gameCameraPosContainer.localPosition = _v;		
		*/
		
		_v = gameCamera.transform.localPosition;
		_v.x = 0;_v.y = 0;_v.z = 0;
		gameCamera.transform.localPosition = _v;				
		
		//GameManager.me.gameCamera.fieldOfView = 10;
		
		camNumber = 0;
		changeCamera(true);
		
		if(GameManager.me.cutSceneManager.nowOpenCutScene == false)
		{
			playCam();	
		}
	}	
	
	int camNumber = 0;
	
	private float rx = 0;
	private float ry = 0;
	private Quaternion _defaultRotation;
	
	public void changeCamera(bool settingCameraRightNow = false)
	{
		if(camNumber >= GameManager.info.setupData.cameraPresetLength)
		{
			camNumber = 0;
		}
		
		gameCameraPosContainer.localPosition = GameManager.info.setupData.cameraPreset[camNumber].position;
		
		_q = gameCameraContainer.rotation;
		_v = GameManager.info.setupData.cameraPreset[camNumber].rotation;
		_q.eulerAngles = _v;
		gameCameraContainer.rotation = _q;
		_defaultRotation = _q;

		//370,819,-1504|0,0,0|21
		//370,1121,-2168|0,0,0|15

		_q = GameManager.me.gameCamera.transform.localRotation;
		_v = _q.eulerAngles;			
		_v.x = 27.0f;_v.y = 0.0f;_v.z = 0.0f;_q.eulerAngles = _v;
		GameManager.me.gameCamera.transform.localRotation = _q;			

		fov = GameManager.info.setupData.cameraPreset[camNumber].fov;

		GameManager.me.gameCamera.fieldOfView = fov;
		setCameraCenter(settingCameraRightNow);			
		++camNumber;
	}		
	

}
