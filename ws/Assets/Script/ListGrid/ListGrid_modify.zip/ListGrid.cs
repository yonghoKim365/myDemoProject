﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class ListGrid : MonoBehaviour {

	public enum Direction
	{
		vertical, horizontal
	}

	public Direction direction = Direction.vertical;

	public bool reUseItem = true;

	//public bool isLock = true;

	public int itemPerLine = 1;

	public float cellWidth = 100.0f;
	public float cellHeight = 100.0f;
	
	public UIListGridItemPanelBase listItem;
	public UIListGridItemPanelBase[] listItem_subs;
	public int listItemSubIndex=-1;
	
	private UIListGridItemPanelBase firstItem;
	private UIListGridItemPanelBase lastItem;
	public UIListGridItemPanelBase endLineObject;
	[HideInInspector]
	public int dumpItemN = 1;

	private List<UIListGridItemPanelBase> itemList = new List<UIListGridItemPanelBase>();

	private List<object> dataList;

	public bool isViewLastPanel=true;
	
	public float addSlotTime=0.01f;

	UIPanel panel = null;//NGUITools.FindInParents<UIPanel>(gameObject);

	void Awake()
	{
		_dragScrollView = NGUITools.FindInParents<UIScrollView>(gameObject);
		panel = NGUITools.FindInParents<UIPanel>(gameObject);
	}

	void OnEnable()
	{
		_dragScrollView = NGUITools.FindInParents<UIScrollView>(gameObject);	
		panel = NGUITools.FindInParents<UIPanel>(gameObject);
	}

	public GameObject lastPanel;
	

	private int itemN = 0;
	
	
	private int _index = 0;
	public int index
	{
		get{return _index;}
		set{
			if(_index == value)return;
			if(value<0||value > dataList.Count - itemList.Count)return;
			_index = value;
			setPosition();
		}
	}


	Vector3 _v;

	public void reposition()
	{
		index = checkFirstIndex();

		int i= 0;
		if(index == 0)i++;
		foreach(UIListGridItemPanelBase item in itemList)
		{
			//item.transform.localPosition = Vector3.zero + new Vector3(0,-(dataList.Count-1)*cellHeight,0);
			_v = item.transform.localPosition;

			if(direction == Direction.vertical)
			{
				_v.x = 0.0f; 
				_v.y = -(index+i)*cellHeight; 
				_v.z = 0.0f;
			}
			else
			{
				_v.x = -(index+i)*cellWidth; 
				_v.y = 0.0f; 
				_v.z = 0.0f;
			}

			item.transform.localPosition = _v;
			setItemData(item);
			i++;
		}
	}


	public void setData(List<object> list,bool isResetPos)
	{
		//addSlotTime = 0.01f;
		UIScrollView drag = NGUITools.FindInParents<UIScrollView>(gameObject);
		float dragY = (direction == Direction.vertical)?drag.transform.localPosition.y:drag.transform.localPosition.x;

		_setPosNum = 10;

		itemList.Clear();
		dataList = list;

		itemClear();

		if(reUseItem)
		{
			setList();
		}
		else
		{
			setAllList();
		}
		//object tmpObj = new object();
		
		//dataList.Add(tmpObj);
		if(isResetPos==false){
			_v = drag.transform.localPosition;

			if(direction == Direction.vertical)
			{
				_v.x = drag.transform.localPosition.x;
				_v.y = dragY;
				_v.z = drag.transform.localPosition.z;
			}
			else
			{
				_v.x = dragY;
				_v.y = drag.transform.localPosition.y;
				_v.z = drag.transform.localPosition.z;
			}

			drag.transform.localPosition = _v;
			setPosition();
		}
		else
		{
		}

		reposition();

	}


	UIListGridItemPanelBase[] itemPool;

	int itemPoolIndex = 0;
	int itemItemPoolLength = 0;
	UIListGridItemPanelBase getItem()
	{
		if(itemPoolIndex < itemItemPoolLength)
		{
			UIListGridItemPanelBase item = itemPool[itemPoolIndex];
			item.gameObject.SetActive(true);
			++itemPoolIndex;
			return item;
		}
		else
		{
			if(listItemSubIndex<0){
				return Instantiate(listItem) as UIListGridItemPanelBase;
			}else{
				return Instantiate(listItem_subs[listItemSubIndex]) as UIListGridItemPanelBase;
			}
		}
	}

	public void itemClear(bool destroy = false)
	{
		if(destroy)
		{
			Transform[] tList = this.gameObject.GetComponentsInChildren<Transform>();
			//Debug.LogWarning("==============item Count "+tList.Length);
			foreach(Transform t in tList)
			{
				if(t.gameObject!=this.gameObject)
				{
					t.gameObject.SetActive(true);
					GameObject.Destroy(t.gameObject);
				}
			}
		}
		else
		{
			itemPool = this.gameObject.GetComponentsInChildren<UIListGridItemPanelBase>();
			itemPoolIndex = 0;
			itemItemPoolLength = itemPool.Length;
			int dataLength = dataList.Count;
			for(int i = 0; i < itemItemPoolLength; ++i)
			{
				itemPool[i].gameObject.SetActive(false);
			}
		}
	}
	
	private void setList()
	{
		_listDrawStatus =  ListDrawStatus.start;

		SetListSequence0();
		SetListSequence1();
		SetListSequence2();
		reposition();

		_listDrawStatus = ListDrawStatus.idle;
		_setPosNum = 0;

		//_dragScrollView.ResetPosition();
	}
	
	private void SetListSequence0(){
		if(listItem==null || (listItemSubIndex>=0 && listItem_subs!=null && listItem_subs.Length<=listItemSubIndex))
		{
			Debug.LogError("listItem is Null");
			return;
		}

		if(panel == null)
		{
			panel = NGUITools.FindInParents<UIPanel>(gameObject);
		}

		if(panel == null|| panel.clipping == UIDrawCall.Clipping.None)return;
		//====get itemN
		int itemMax;

		if(direction == Direction.vertical)
		{
			itemMax = Mathf.CeilToInt(panel.clipRange.w/cellHeight)+dumpItemN*2+2;
		}
		else
		{
			itemMax = Mathf.CeilToInt(panel.clipRange.z/cellWidth)+dumpItemN*2+2;
		}

		itemN = Mathf.Min(itemMax, dataList.Count);
		
		//LineManager.log("SetList() 1");
		
		if(endLineObject!=null)
		{
			GameObject endLine = Instantiate(endLineObject) as GameObject;
			endLine.transform.parent = this.transform;
			endLine.transform.localScale = Vector3.one;
			endLine.transform.localPosition = Vector3.zero+ new Vector3(0,-panel.clipRange.w,0);
			endLine.transform.localScale = new Vector3(1,1,1);
		}
		
	}
	int SetListSequence_i;
	private void SetListSequence1(){
		SetListSequence_i = 0;
	}
	private void SetListSequence2(){
		//Debug.Log("SetList() 2");
		//instace item
		for(int i=0;SetListSequence_i<itemN;++i){ //&& i<1;i++){
			UIListGridItemPanelBase item = getItem();

			item.transform.parent = this.transform;
			if(SetListSequence_i == 0)
			{
				item.transform.localPosition = Vector3.zero;
				firstItem = item;
			}
			else if(SetListSequence_i == itemN-1)
			{
				if(direction == Direction.vertical)
				{
					_v.x = 0.0f;
					_v.y = -(dataList.Count-1)*cellHeight;
					_v.z = 0;
				}
				else
				{
					_v.y = 0.0f;
					_v.x = -(dataList.Count-1)*cellWidth;
					_v.z = 0;
				}

				item.transform.localPosition = _v;
				lastItem = item;
			}
			else
			{

				if(direction == Direction.vertical)
				{
					_v.x = 0.0f;
					_v.y = -SetListSequence_i*cellHeight;
					_v.z = 0;
				}
				else
				{
					_v.y = 0.0f;
					_v.x = -SetListSequence_i*cellWidth;
					_v.z = 0;
				}
				
				item.transform.localPosition = _v;
				itemList.Add(item);
			}
			
			setItemData(item);
			setItemImgLoad(item);
			
			SetListSequence_i++;

			_v.x = 1;
			_v.y = 1;
			_v.z = 1;
			item.gameObject.transform.localScale = _v;
		}
	}
	private void SetListSequence3(){
		Debug.Log("(dataList.Count+1).ToString() : " + (dataList.Count+1).ToString());
		
		if(lastPanel!=null && isViewLastPanel==true){
			GameObject lp = (GameObject)Instantiate(lastPanel);
			lp.transform.parent = transform;

			if(direction == Direction.vertical)
			{
				_v.x = 0.0f;
				_v.y = -dataList.Count*cellHeight;
				_v.z = 0;
			}
			else
			{
				_v.y = 0.0f;
				_v.x = -dataList.Count*cellWidth;
				_v.z = 0;
			}

			lp.transform.localPosition = _v;

			UILabel label = lp.GetComponentInChildren<UILabel>();
			if(label!=null){
				label.text = (dataList.Count+1).ToString();
			}
			lp.gameObject.transform.localScale = new Vector3(1,1,1);
		}
	}
	public void setAllItemImgLoad()
	{
		foreach(UIListGridItemPanelBase item in itemList)
		{
			setItemImgLoad(item);
		}
	}
	private void setItemImgLoad(UIListGridItemPanelBase item)
	{
		if(item.gameObject.activeSelf==true){
			item.setLoad();
		}
	}
	private void setItemData(UIListGridItemPanelBase item)
	{
		int idx;
		if(direction == Direction.vertical)
		{
			idx = -(int)(item.transform.localPosition.y/cellHeight);
		}
		else
		{
			idx = -(int)(item.transform.localPosition.x/cellWidth);
		}

		try{
			if(item.gameObject.activeSelf==true){

				if(dataList.Count > idx)
				{
					item.setIndex(idx);
					item.setData(dataList[idx]);
					
					setItemImgLoad(firstItem);
					if(lastItem!=null){
						setItemImgLoad(lastItem);
					}
				}
			}
		}catch(Exception e){
			Debug.LogError("INDEX EXCEPTION :  listGrid setItemData() : " + idx);
			Debug.LogError(e.Message);
		}
	}


	private int checkFirstIndex()
	{
		//UIPanel panel = NGUITools.FindInParents<UIPanel>(gameObject);
		if(panel == null){
			return _index;
		}

		if(direction == Direction.vertical)
		{
			return Mathf.FloorToInt((panel.transform.localPosition.y)/cellHeight);
		}
		else
		{
			return Mathf.FloorToInt((panel.transform.localPosition.x)/cellWidth);
		}
		
	}
	
	private void setPosition(bool resetPosition = false)
	{
		if(itemList == null || dataList == null) return;

		//UIPanel panel = NGUITools.FindInParents<UIPanel>(gameObject);
		if(panel == null)return;
		float _y = (direction == Direction.vertical)?panel.transform.localPosition.y:panel.transform.localPosition.x;
		if(resetPosition) _y = 0.0f;

		int itemCount = itemList.Count;
		int dataCount = dataList.Count;

		foreach(UIListGridItemPanelBase item in itemList)
		{
			if(direction == Direction.vertical)
			{
				//moveDown!!
				if(item.transform.localPosition.y + _y > cellHeight+10)
				{
					if(item.transform.localPosition.y - (cellHeight*itemCount) > -(dataCount-1)*cellHeight)
					{
						_v.x = 0;
						_v.y = item.transform.localPosition.y - (cellHeight*itemCount);
						_v.z = 0;
						item.transform.localPosition = _v;
						setItemData(item);
						setItemImgLoad(item);
					}
					else
					{

					}
				}
				//moveUP!!
				else if(item.transform.localPosition.y + _y < -cellHeight*(itemCount-2))
				{
					if(item.transform.localPosition.y + (cellHeight*itemCount) <= -cellHeight)
					{
						_v.x = 0;
						_v.y = item.transform.localPosition.y + (cellHeight*itemCount);
						_v.z = 0;

						item.transform.localPosition = _v;
						setItemData(item);
						setItemImgLoad(item);
					}
				}
				else
				{

				}
			}
			else
			{
				//moveDown!!
				if(item.transform.localPosition.x + _y > cellWidth+10)
				{
					if(item.transform.localPosition.x - (cellWidth*itemCount) > -(dataCount-1)*cellWidth)
					{
						_v.x = item.transform.localPosition.x - (cellWidth*itemCount);
						_v.y = 0;
						_v.z = 0;
						item.transform.localPosition = _v;
						setItemData(item);
						setItemImgLoad(item);
					}
				}
				//moveUP!!
				else if(item.transform.localPosition.x + _y < -cellWidth*(itemCount-2))
				{
					if(item.transform.localPosition.x + (cellWidth*itemCount) <= -cellWidth)
					{
						_v.x = item.transform.localPosition.x + (cellWidth*itemCount);
						_v.y = 0;
						_v.z = 0;

						item.transform.localPosition = _v;
						setItemData(item);
						setItemImgLoad(item);
					}
				}

			}
		}
	}
	private float panelPrevPosition = 0;
	private bool isMoved = false;
	private bool checkMovePanel()
	{
		
		//UIPanel panel = NGUITools.FindInParents<UIPanel>(gameObject);
		if(panel == null) return true;
		bool isMove = true;

		if(direction == Direction.vertical)
		{
			if(Mathf.Abs(panel.transform.localPosition.y - panelPrevPosition)<1) isMove = false;
			else isMove = true;
			
			panelPrevPosition = panel.transform.localPosition.y;

		}
		else
		{
			if(Mathf.Abs(panel.transform.localPosition.x - panelPrevPosition)<1) isMove = false;
			else isMove = true;
			
			panelPrevPosition = panel.transform.localPosition.x;
		}

		if(isMoved==isMove)return true;

		if(isMoved == false && isMove == true)
		{
			_setPosNum = 0;
		}

		isMoved = isMove;
		return isMove;
		
		
	}
	// Use this for initialization
	
	// Update is called once per frame

	private enum ListDrawStatus
	{
		idle, start, drawing
	}

	ListDrawStatus _listDrawStatus = ListDrawStatus.idle;

	//private string _listDrawStatus="";//START , DRAWING, ""
	private float _listDrawDelayTime=0;

	UIScrollView _dragScrollView = null;

	int _setPosNum = 10;
	void Update () {

		if(reUseItem == false) return;

		if(_listDrawStatus==ListDrawStatus.idle)
		{

			index = checkFirstIndex();

			if(!checkMovePanel())
			{
				setAllItemImgLoad();
				_setPosNum = 0;
			}

			if(_setPosNum++ < 3) setPosition();

			//setPosition();
			//UIScrollView drag = NGUITools.FindInParents<UIScrollView>(gameObject);
			//if (drag != null) drag.UpdateScrollbars(true);

			if(_dragScrollView != null) _dragScrollView.UpdateScrollbars(true);

		}else if(_listDrawStatus==ListDrawStatus.start){
			SetListSequence0();
			SetListSequence1();
			/*	
			for(int i=0;i<8;i++){
				SetListSequence2();
			}
			*/
			_listDrawDelayTime = Time.time;
			_listDrawStatus = ListDrawStatus.drawing;
		}else if(_listDrawStatus==ListDrawStatus.drawing){
			//if(_listDrawDelayTime<Time.time){
			//	_listDrawDelayTime = Time.time+addSlotTime;
				SetListSequence2();
				if(SetListSequence_i>=itemN)
				{
					SetListSequence3();
					reposition();
					_listDrawStatus = ListDrawStatus.idle;
				}
			//}
		}
	}



	private void setAllList(){
		//Debug.Log("SetList() 2");
		//instace item
		int len = dataList.Count;
		for(int i=0;i<len;++i)
		{
			UIListGridItemPanelBase item = getItem();
			
			item.transform.parent = this.transform;
			if(i == 0)
			{
				item.transform.localPosition = Vector3.zero;
				firstItem = item;
			}
			else if(i == len-1)
			{
				if(direction == Direction.vertical)
				{
					_v.x = 0.0f;
					_v.y = -(len-1)*cellHeight;
					_v.z = 0;
				}
				else
				{
					_v.y = 0.0f;
					_v.x = -(len-1)*cellWidth;
					_v.z = 0;
				}
				
				item.transform.localPosition = _v;
				lastItem = item;
			}
			else
			{
				
				if(direction == Direction.vertical)
				{
					_v.x = 0.0f;
					_v.y = -i*cellHeight;
					_v.z = 0;
				}
				else
				{
					_v.y = 0.0f;
					_v.x = -i*cellWidth;
					_v.z = 0;
				}
				
				item.transform.localPosition = _v;
				itemList.Add(item);
			}
			
			setItemData(item);
			setItemImgLoad(item);

			_v.x = 1;
			_v.y = 1;
			_v.z = 1;
			item.gameObject.transform.localScale = _v;
		}
	}

}