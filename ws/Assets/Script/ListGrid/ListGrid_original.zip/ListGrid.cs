﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class ListGrid : MonoBehaviour {

	public enum Direction
	{
		vertical, horizontal
	}

	public Direction direction = Direction.vertical;

	public bool reUseItem = true;

	//public bool isLock = true;

	public int itemPerLine = 1;

	public float cellWidth = 100.0f;
	public float cellHeight = 100.0f;
	
	public UIListGridItemPanelBase listItem;
	public UIListGridItemPanelBase[] listItem_subs;
	public int listItemSubIndex=-1;
	
	private UIListGridItemPanelBase firstItem;
	private UIListGridItemPanelBase lastItem;
	public UIListGridItemPanelBase endLineObject;

	[HideInInspector]
	public int dumpItemN = 1;

	private List<UIListGridItemPanelBase> itemList = new List<UIListGridItemPanelBase>();

	private List<object> dataList;

	private float _pibotY = -9999;

	public bool isViewLastPanel=false;
	
	public float addSlotTime=0.01f;

	public GameObject lastPanel;
	

	private float pibotY
	{
		get
		{
			if(_pibotY  == -9999)
			{
				UIPanel panel = NGUITools.FindInParents<UIPanel>(gameObject);
				if(panel != null)_pibotY = panel.clipRange.y;
				
			}
			return _pibotY;
		}
	}
	private int itemN = 0;


	private int _index = 0;
	public int index
	{
		get{return _index;}
		set{
			if(_index == value)return;
			if(value<0||value > dataList.Count - itemList.Count)return;
			_index = value;
			setPosition();
		}
	}


	Vector3 _v;


	public void reposition()
	{	
		index = checkFirstIndex();
		int i= 0;
		if(index == 0)i++;
		foreach(UIListGridItemPanelBase item in itemList)
		{
			item.transform.localPosition = new Vector3(0,-(index+i)*cellHeight,0);
			setItemData(item);
			i++;
		}
		setPosition();
	}



	public void setData(List<object> list,bool isResetPos)
	{
		addSlotTime = 0.01f;
		UIScrollView drag = NGUITools.FindInParents<UIScrollView>(gameObject);
		float dragY = drag.transform.localPosition.y;
		
		itemList.Clear();
		itemClear();
		dataList = list;
		setList();
		
		if(isResetPos==false){
			drag.transform.localPosition = new Vector3(drag.transform.localPosition.x,dragY,drag.transform.localPosition.z);
			setPosition();
		}
	}


	public void itemClear(bool destroy = false)
	{

		Transform[] tList = this.gameObject.GetComponentsInChildren<Transform>();
		//Debug.LogWarning("==============item Count "+tList.Length);
		foreach(Transform t in tList)
		{
			if(t.gameObject!=this.gameObject)
			{
				t.gameObject.SetActive(true);
				GameObject.Destroy(t.gameObject);
			}
		}

	}
	
	private void setList()
	{
		_listDrawStatus = "START";
		//SetListSequence0();
		//SetListSequence1();
		//SetListSequence2();
		//reposition();
	}
	
	private void SetListSequence0(){
		if(listItem==null || (listItemSubIndex>=0 && listItem_subs!=null && listItem_subs.Length<=listItemSubIndex))
		{
			Debug.LogError("listItem is Null");
			return;
		}
		UIPanel panel = NGUITools.FindInParents<UIPanel>(gameObject);
		if(panel == null|| panel.clipping == UIDrawCall.Clipping.None)return;
		//====get itemN
		int itemMax = Mathf.CeilToInt(panel.clipRange.w/cellHeight)+dumpItemN*2+2;
		itemN = Mathf.Min(itemMax, dataList.Count);
		
		//LineManager.log("SetList() 1");
		
		if(endLineObject!=null)
		{
			GameObject endLine = Instantiate(endLineObject) as GameObject;
			endLine.transform.parent = this.transform;
			endLine.transform.localScale = Vector3.one;
			endLine.transform.localPosition = Vector3.zero+ new Vector3(0,-panel.clipRange.w,0);
			endLine.transform.localScale = new Vector3(1,1,1);
		}
	}

	int SetListSequence_i;
	private void SetListSequence1(){
		SetListSequence_i = 0;
	}
	private void SetListSequence2(){
		//LineManager.log("SetList() 2");
		//instace item
		for(int i=0;SetListSequence_i<itemN && i<1;i++){
			UIListGridItemPanelBase item;
			if(listItemSubIndex<0){
				item = Instantiate(listItem) as UIListGridItemPanelBase;
			}else{
				item = Instantiate(listItem_subs[listItemSubIndex]) as UIListGridItemPanelBase;
			}
			//GameObject item = panels[i].gameObject;
			
			item.transform.parent = this.transform;
			if(SetListSequence_i == 0)
			{
				item.transform.localPosition = Vector3.zero;
				firstItem = item;
			}
			else if(SetListSequence_i == itemN-1)
			{
				item.transform.localPosition = Vector3.zero + new Vector3(0,-(dataList.Count-1)*cellHeight,0);
				lastItem = item;
			}
			else
			{
				item.transform.localPosition = Vector3.zero + new Vector3(0,-SetListSequence_i*cellHeight,0);
				itemList.Add(item);
			}
			
			setItemData(item);
			setItemImgLoad(item);
			
			SetListSequence_i++;
			
			item.gameObject.transform.localScale = new Vector3(1,1,1);
		}
	}
	private void SetListSequence3(){
	}

	public void setAllItemImgLoad()
	{
		foreach(UIListGridItemPanelBase item in itemList)
		{
			setItemImgLoad(item);
		}
	}
	private void setItemImgLoad(UIListGridItemPanelBase item)
	{
		if(item.gameObject.activeSelf==true){
			item.setLoad();
		}
	}
	private void setItemData(UIListGridItemPanelBase item)
	{
		int idx = -(int)(item.transform.localPosition.y/cellHeight);

		try{
			if(item.gameObject.activeSelf==true){

				if(dataList.Count > idx)
				{
					item.setIndex(idx);
					item.setData(dataList[idx]);
					
					setItemImgLoad(firstItem);
					if(lastItem!=null){
						setItemImgLoad(lastItem);
					}
				}
			}
		}catch(Exception e){
			Debug.LogError("INDEX EXCEPTION :  listGrid setItemData() : " + idx);
			Debug.LogError(e.Message);
		}
	}


	private int checkFirstIndex()
	{
		UIPanel panel = NGUITools.FindInParents<UIPanel>(gameObject);
		if(panel == null){
			return _index;
		}
		
		return Mathf.FloorToInt((panel.transform.localPosition.y)/cellHeight);
	}
	
	private void setPosition(bool resetPosition = false)
	{
		UIPanel panel = NGUITools.FindInParents<UIPanel>(gameObject);
		if(panel == null)return;
		float _y = panel.transform.localPosition.y;
		
		foreach(UIListGridItemPanelBase item in itemList)
		{
			//moveDown!!
			if(item.transform.localPosition.y + _y > cellHeight+10){
				if(item.transform.localPosition.y - (cellHeight*itemList.Count) > -(dataList.Count-1)*cellHeight)
				{
					item.transform.localPosition = new Vector3(0,item.transform.localPosition.y - (cellHeight*itemList.Count),0);
					setItemData(item);
					setItemImgLoad(item);
				}
			}
			//moveUP!!
			else if(item.transform.localPosition.y + _y < -cellHeight*(itemList.Count-2))
			{
				if(item.transform.localPosition.y + (cellHeight*itemList.Count) <= -cellHeight)
				{
					item.transform.localPosition = new Vector3(0,item.transform.localPosition.y + (cellHeight*itemList.Count),0);
					setItemData(item);
					setItemImgLoad(item);
				}
			}
			
			//setItemData(item);
		}
	}
	private float panelPrevPosition = 0;
	private bool isMoved = false;
	private bool checkMovePanel()
	{
		
		UIPanel panel = NGUITools.FindInParents<UIPanel>(gameObject);
		if(panel == null) return true;
		bool isMove = true;
		if(Mathf.Abs(panel.transform.localPosition.y - panelPrevPosition)<1)
		{
			isMove = false;
		}
		else
		{
			isMove = true;
		}
		
		panelPrevPosition = panel.transform.localPosition.y;
		
		if(isMoved==isMove)return true;
		isMoved = isMove;
		return isMove;
		
		
	}
	// Use this for initialization
	
	// Update is called once per frame
	private string _listDrawStatus="";//START , DRAWING, ""
	private float _listDrawDelayTime=0;
	void Update () {
		if(_listDrawStatus==""){
			index = checkFirstIndex();
			if(!checkMovePanel())setAllItemImgLoad();
			//setPosition();

		}else if(_listDrawStatus=="START"){
			SetListSequence0();
			SetListSequence1();
			/*	
			for(int i=0;i<8;i++){
				SetListSequence2();
			}
			*/
			_listDrawDelayTime = Time.time;
			_listDrawStatus = "DRAWING";
		}else if(_listDrawStatus=="DRAWING"){
			if(_listDrawDelayTime<Time.time){
				_listDrawDelayTime = Time.time+addSlotTime;
				SetListSequence2();
				if(SetListSequence_i>=itemN){
					SetListSequence3();
					reposition();
					_listDrawStatus = "";
				}
			}
		}
	}

}