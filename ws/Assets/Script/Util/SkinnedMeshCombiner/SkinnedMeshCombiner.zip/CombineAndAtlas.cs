using UnityEngine;

using System.Collections;

using System.IO;

 

public class CombineAndAtlas : MonoBehaviour {

    
    public static void Merge(GameObject root, bool hasNormalMaps = false, int maxAtlasSize = 2048)
	{

        SkinnedMeshRenderer[] SMRs;

        int vertCount = 0;
        int normCount = 0;
        int tanCount = 0;
        int triCount = 0;
        int uvCount = 0;
        int boneCount = 0;
        int bpCount = 0;
        int bwCount = 0;

        Transform[] bones;
        Matrix4x4[] bindPoses;
        BoneWeight[] weights;

        Vector3[] verts;
        Vector3[] norms;
        Vector4[] tans;

        int[] tris;
        Vector2[] uvs;
        Texture2D[] textures;
        Texture2D[] normalmaps;

        int vertOffset = 0;
        int normOffset = 0;
        int tanOffset = 0;
        int triOffset = 0;
        int uvOffset = 0;
        int meshOffset = 0;

        int  boneSplit = 0;

        int bNum = 0;

 

        int[] bCount;

 

        SMRs = root.GetComponentsInChildren<SkinnedMeshRenderer>();

 

        foreach (SkinnedMeshRenderer smr in SMRs) {

            vertCount += smr.sharedMesh.vertices.Length;

            normCount += smr.sharedMesh.normals.Length;

            tanCount += smr.sharedMesh.tangents.Length;

            triCount += smr.sharedMesh.triangles.Length;

            uvCount += smr.sharedMesh.uv.Length;

            boneCount += smr.bones.Length;

            bpCount += smr.sharedMesh.bindposes.Length;

            bwCount += smr.sharedMesh.boneWeights.Length;

            bNum++;

        }

 

        bCount = new int[3];

        bones = new Transform[boneCount];

        weights = new BoneWeight[bwCount];

        bindPoses = new Matrix4x4[bpCount];

        textures = new Texture2D[bNum];

        normalmaps = new Texture2D[bNum];

        

        foreach (SkinnedMeshRenderer smr in SMRs) {

 

            for(int b1 = 0; b1 < smr.bones.Length; b1++) {

                bones[bCount[0]] = smr.bones[b1];

                

                bCount[0]++;

            }

 

            for(int b2 = 0; b2 < smr.sharedMesh.boneWeights.Length; b2++) {

                weights[bCount[1]] = smr.sharedMesh.boneWeights[b2];

                weights[bCount[1]].boneIndex0 += boneSplit;

                weights[bCount[1]].boneIndex1 += boneSplit;

                weights[bCount[1]].boneIndex2 += boneSplit;

                weights[bCount[1]].boneIndex3 += boneSplit;

 

                bCount[1]++;

            }

 

            for(int b3 = 0; b3 < smr.sharedMesh.bindposes.Length; b3++) {

                bindPoses[bCount[2]] = smr.sharedMesh.bindposes[b3];

 

                bCount[2]++;

            }

 

            boneSplit += smr.bones.Length;

        }

 

        verts = new Vector3[vertCount];

        norms = new Vector3[normCount];

        tans = new Vector4[tanCount];

        tris = new int[triCount];

        uvs = new Vector2[uvCount];

 

        foreach (SkinnedMeshRenderer smr in SMRs) {

            

            foreach (int i in smr.sharedMesh.triangles) {

                tris[triOffset++] = i + vertOffset;

            }

 

            foreach (Vector3 v in smr.sharedMesh.vertices) {

                verts[vertOffset++] = v;

            }

 

            foreach (Vector3 n in smr.sharedMesh.normals) {

                norms[normOffset++] = n;

            }

 

            foreach (Vector4 t in smr.sharedMesh.tangents) {

                tans[tanOffset++] = t;

            }

 

            foreach (Vector2 uv in smr.sharedMesh.uv) {

                uvs[uvOffset++] = uv;

            }

 

            textures[meshOffset] = (Texture2D) smr.sharedMaterial.GetTexture("_MainTex");

            if( hasNormalMaps ) normalmaps[meshOffset] = (Texture2D) smr.sharedMaterial.GetTexture("_BumpMap");

 

            meshOffset++;

 

            Destroy( smr.gameObject );

        }

 

        Texture2D tx = new Texture2D (1,1);

        Rect[] r = tx.PackTextures (textures, 0, maxAtlasSize);

        

        Texture2D nm = new Texture2D (1,1);

        

        if( hasNormalMaps ) {

            nm.PackTextures (normalmaps, 0, maxAtlasSize);

        }

 

        uvOffset = 0;

        meshOffset = 0;

 

        foreach (SkinnedMeshRenderer smr in SMRs) {

 

            foreach (Vector2 uv in smr.sharedMesh.uv) {

                uvs[uvOffset].x = Mathf.Lerp (r[meshOffset].xMin, r[meshOffset].xMax, uv.x % 1);

                uvs[uvOffset].y = Mathf.Lerp (r[meshOffset].yMin, r[meshOffset].yMax, uv.y % 1);

                uvOffset ++;
            }
            meshOffset ++;
        }

        Material mat;

        if( hasNormalMaps ) mat = new Material( Shader.Find("Bumped Diffuse") );
        else mat = new Material( Shader.Find("Unlit/Texture") );

        
        mat.SetTexture("_MainTex", tx);

        if( hasNormalMaps ) mat.SetTexture("_BumpMap", nm);

        //New Mesh

        Mesh me = new Mesh();
        me.name = root.gameObject.name;
        me.vertices = verts;
        me.normals = norms;
        me.tangents = tans;
        me.boneWeights = weights;
        me.uv = uvs;
        me.triangles = tris;
        me.bindposes = bindPoses;

        SkinnedMeshRenderer newSMR = root.AddComponent<SkinnedMeshRenderer>();

        newSMR.sharedMesh = me;
        newSMR.bones = bones;
        newSMR.updateWhenOffscreen = true;

        root.renderer.material = mat;

        // reset animator culling mode so that Mecanim recognizes renderer bounds again

        Animator animator = root.GetComponent<Animator>();

        if( animator ) 
		{
            animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            animator.cullingMode = AnimatorCullingMode.BasedOnRenderers;
        }
    }
}